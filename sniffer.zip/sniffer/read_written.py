import sys
import time
import os

option = sys.argv[1]
port = sys.argv[2]

while True:
    if option == '-p':
        if os.path.exists('./P' + str(port) + '.txt'):
            with open('./P' + str(port) + '.txt', 'r') as logger:
                data = logger.read()
                print(data.encode('utf-8', 'ignore'))
                time.sleep(10)