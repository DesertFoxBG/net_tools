import pyspeedtest
import ipwhois
import pprint

class NetSpeedTest:
    def __init__(self):
        self.st = pyspeedtest.SpeedTest()
        self.ping_test = self.ping()
        self.download_speed = self.download()
        self.upload_speed = self.upload()
        self.server = self.st.chooseserver()

    def ping(self):
        return int(self.st.ping())

    def download(self):
        return round(self.st.download() / 1000000, 2)

    def upload(self):
        return round(self.st.upload() / 1000000, 2)

def speedTest():
    test = NetSpeedTest()
    log = '\n===> SPEED-TEST-STATISTICS-------[+]\nServer: ' + str(test.server) + '\n' + 'Ping: ' + str(test.ping_test) + ' ms\n' + 'Download speed: ' + str(test.download_speed) + ' Mbps\n' + 'Upload speed: ' + str(test.upload_speed) + ' Mbps\n===> END-------------------------[+]\n'
    return log

def basicIPlookup(ip):
    obj = ipwhois.ipwhois.IPWhois(ip)
    results = obj.lookup_whois()
    return results

def advancedIPlookup(ip):
    obj = ipwhois.ipwhois.IPWhois(ip)
    results = obj.lookup_rdap()
    return results

while True:
    option = raw_input('OPTIONS:\n1. Speed Test\n2. IP Lookup\n3. Quit\n=> ')
    if option == '1':
        print(speedTest())
    elif option == '2': # TODO normalize output
        choice = raw_input('1. Basic\n2. Advanced\n=> ')
        if choice == '1':
            ip = raw_input('IP: ')
            pprint.pprint(basicIPlookup(ip))
            print('\n')
        elif choice == '2':
            ip = raw_input('IP: ')
            pprint.pprint(advancedIPlookup(ip))
            print('\n')
            
    elif option == '3':
        break